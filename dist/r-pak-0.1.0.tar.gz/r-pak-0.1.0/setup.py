# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['r_pak']

package_data = \
{'': ['*']}

install_requires = \
['typer[all]>=0.7.0,<0.8.0']

entry_points = \
{'console_scripts': ['r-pak = r_pak.main:app']}

setup_kwargs = {
    'name': 'r-pak',
    'version': '0.1.0',
    'description': '',
    'long_description': 'r-pak \n==================\nThis package acts as a command line wrapper around R package utilities. Use it it install, remove and upgrade R packages.\n\n## Using the package\nInstall packages using `install`\n``` bash\nr-pak install tidyverse\n```\nRemove packages using `remove`\n``` bash\nr-pak remove ggplot2\n```\nUpgrade all packages using `upgrade`\n``` bash\nr-pak upgrade\n```',
    'author': 'piersyork',
    'author_email': 'piersyork@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
