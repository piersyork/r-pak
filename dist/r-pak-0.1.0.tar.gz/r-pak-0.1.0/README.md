r-pak 
==================
This package acts as a command line wrapper around R package utilities. Use it it install, remove and upgrade R packages.

## Using the package
Install packages using `install`
``` bash
r-pak install tidyverse
```
Remove packages using `remove`
``` bash
r-pak remove ggplot2
```
Upgrade all packages using `upgrade`
``` bash
r-pak upgrade
```